# Games roadmap

Crossed out = finished. Add to the list or reorder it any time.

## Edit window
- [x] ~~**Media tab** in Edit: a row for the cover, background, disc / cartridge, screenshots and manual, each with a same-sized preview you can click to enlarge, a text box, Look up (LaunchBox, SteamGridDB), Add (a file of your own), none and "automatic"~~ *(built; waiting for a hands-on check on Windows)*
  - [x] ~~**Clear logo**~~ *(tried in place of the game's name, then taken out again: the name is always text)*
  - Banner and box back: dropped for now
- [x] ~~**Emulator tab** in Edit: Play with, "use for every game on this platform", launch options, and a way into Platform setup~~ *(built; waiting for a hands-on check on Windows)*
- [x] ~~Take the default-emulator text off the game card (it lives in the Emulator tab)~~
- [ ] Per-game **emulator profiles**: launch arguments, commands to run before and after, working folder, environment variables, run as administrator
- [ ] **Tags and custom fields** (co-op, couch, kids) as filters beside genre

## Media
- [x] ~~**Progress bar** for media being fetched, showing which type is being grabbed~~
  - [x] ~~In the Media tab: "Find missing pictures" with a bar and the name of what is being fetched~~
  - [x] ~~On the game's page while its pictures arrive: a slim line saying what is being looked for~~ *(built; waiting for a hands-on check on Windows)*
  - [x] ~~A Stop button on the game's page line~~
- [x] ~~**Bulk media scraper** ("Fetch pictures..." in the Games menu and the selection tools): choose the games (library, selection or a platform), which kinds, and whether to look again; a bar names the game and picture being fetched; Stop~~ *(built; waiting for a hands-on check on Windows)*
  - [x] ~~Covers in the bulk window~~
- [x] ~~**Loading made visible**: a light band sweeps poster cards, the screenshot strip and Media tab previews that are waiting for a picture, and pictures fade in (cover, screenshots, background) instead of popping in~~ *(built; waiting for a hands-on check on Windows)*
- [x] ~~**PDF manual reader**: opens a game's manual as a book, pages grabbed and turned~~ *(built; waiting for a hands-on check on Windows)*
  - [x] ~~Manual row in the Media tab~~
  - [ ] Fetching manuals from an online source
  - [ ] Zoom into a page, a page thumbnail strip, and the PDF's table of contents
- [ ] **Videos**: a trailer link and a hover preview on the poster

## Library
- [x] ~~**Save backups**: back up and restore a game's saves and save states (RetroArch's), per game and all at once before an update~~ *(built; waiting for a hands-on check on Windows)*
- [x] ~~**Library health** view: lost files, duplicates, no platform / cover / details, pictures lacking~~ *(built; waiting for a hands-on check on Windows)*
- [ ] Per-game extras kept with the game: cheats, mods, patches, your own screenshots
- [ ] Play queues and "play random from this collection"

## Bigger projects
- [ ] **Big Picture / controller mode**: a full-screen grid you can drive with a gamepad
- [ ] **Per-platform theming**: console banners and art, matched to the emulator page's console banner
