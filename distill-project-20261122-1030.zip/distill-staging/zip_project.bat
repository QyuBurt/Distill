@echo off
rem zip_project.bat - zips only the Distill project files (source, tests, assets, docs, build files).
rem Leaves out tools, recomps, game_media, icon_cache, Watch, keys, torrents, logs, venvs, build output,
rem saved settings/logins (distill_*.json etc.) and distill\local_keys.py. Nothing in your folder is changed or deleted.
rem Output: distill-project-YYYYMMDD-HHMM.zip next to this file.
setlocal EnableExtensions
cd /d "%~dp0"
if not exist "Distill.spec" goto :notsource
if not exist "distill\constants.py" goto :notsource

for /f %%T in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd-HHmm"') do set "STAMP=%%T"
set "NAME=distill-project-%STAMP%"
set "STAGE=%TEMP%\%NAME%"
set "OUT=%CD%\%NAME%.zip"
if exist "%STAGE%" rd /s /q "%STAGE%"
mkdir "%STAGE%\distill-staging" || goto :fail
set "DEST=%STAGE%\distill-staging"

rem project folders only (whitelist), minus caches and personal files
for %%D in (distill tests devtools changes .github) do (
    if exist "%%D\" (
        robocopy "%%D" "%DEST%\%%D" /E /NFL /NDL /NJH /NJS /NP /XD __pycache__ .pytest_cache .ruff_cache /XF *.pyc local_keys.py distill_*.json distill_*.txt distill_*.db distill_*.db-wal distill_*.db-shm *.part >nul
        if errorlevel 8 goto :fail
    )
)

rem top-level project files
for %%F in (Distill.pyw Distill.spec README.md CHECKLIST.md build_exe.bat clean_for_sharing.bat zip_project.bat distill.ico distill.png make_vinyl_sounds.py pyproject.toml requirements.txt requirements-dev.txt .gitignore .gitattributes) do (
    if exist "%%F" copy /y "%%F" "%DEST%\" >nul
)

if exist "%OUT%" del /f /q "%OUT%"
tar -a -cf "%OUT%" -C "%STAGE%" distill-staging || goto :fail
rd /s /q "%STAGE%"
echo.
echo Created: %OUT%
goto :end

:notsource
echo This does not look like the Distill source folder - Distill.spec and distill\constants.py were not found next to this file.
exit /b 1

:fail
echo Something went wrong. Nothing in your project folder was changed.
if exist "%STAGE%" rd /s /q "%STAGE%"
exit /b 1

:end
endlocal
